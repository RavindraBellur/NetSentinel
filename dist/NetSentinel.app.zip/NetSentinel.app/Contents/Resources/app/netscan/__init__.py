"""NetSentinel - LAN discovery, monitoring and multi-site network console."""

__version__ = "1.16.0"
